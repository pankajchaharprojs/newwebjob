using System;
using System.Configuration;
using Gravity.SDK.KeyVault.Helpers;
using Images.Sdk.Service.Client.TokenAdapter;
using Images.Sdk.Storage.Blob;
using Microsoft.Extensions.Logging;
using Ninject;
using Ninject.Web.Common;
using syngo.Cloud.PIC.Data.Access.Data.Contracts.Study;
using syngo.Cloud.PIC.Data.Access.Storage.EF.Study;
using syngo.Cloud.PIC.Data.Access.Storage.Helpers;
using syngo.Cloud.PIC.Data.Access.Storage.Study;
using syngo.Cloud.PIC.Data.Access.Storage.Table;
using syngo.Cloud.PIC.Handler.Common;
using syngo.Cloud.PIC.Service.Client;
using syngo.Cloud.PIC.Service.Client.ConfigAdapter;
using syngo.Cloud.PIC.Service.Client.CoreConfigAdapter;
using syngo.Cloud.PIC.Service.Client.HttpAdapter.Contracts;
using syngo.Cloud.PIC.Service.Client.MetadataAdapter;
using syngo.Cloud.PIC.Service.Client.NetworkAdapter;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public class NinjectModule : Ninject.Modules.NinjectModule
    {
        public override void Load()
        {
            Kernel.Bind<IStudyContext>().To<StudyContext>().InTransientScope();
            Kernel.Bind<IStudyUow>().To<StudyUow>().InTransientScope();
            Kernel.Bind<RepositoryFactories<StudyContext>>()
                .To<StudyRepositoryFactories>().InTransientScope();
            Kernel.Bind<IRepositoryProvider<StudyContext>>()
                .To<RepositoryProvider<StudyContext>>().InTransientScope();

            Kernel.Bind<IEvaluateDeleteRules>().To<EvaluateDeleteRules>();
            Kernel.Bind<IDeleteStudy>().To<DeleteStudy>();


            Kernel.Bind<IWebServiceProxy>().ToConstructor(c =>
             new WebServiceProxy(Kernel.Get<IHttpWebClient>(), Kernel.Get<ITokenAdapter>(),
                 int.Parse(ConfigurationManager.AppSettings["HttpMaxRetries"]))).InSingletonScope();

            Kernel.Bind<IMetadataAdapter>().ToConstructor(c =>
              new MetadataAdapter(Kernel.Get<ILoggerFactory>(), Kernel.Get<IWebServiceProxy>(), new Uri(ConfigurationManager.AppSettings["MetadataServiceUrl"])));

            var keyVaultHelper = Kernel.Get<IKeyVaultHelper>();
            string storageConnectionString = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["AzureCStoreConnectionStringSecretName"]);
            Kernel.Bind<IBlobAccess>().ToMethod(m => new BlobAccessor(storageConnectionString)).InSingletonScope().Named("BlobAccessorForReIdentificationBackup");

            Kernel.Bind<IDeleteOutdatedReIdentificationBackups>().To<DeleteOutdatedReIdentificationBackups>();
        }
    }

    public class ExternalDependentNinjectModule : Ninject.Modules.NinjectModule
    {
        public override void Load()
        {
            var nameResolver = Kernel.Get<INameResolver>();
            var keyVaultHelper = Kernel.Get<IKeyVaultHelper>();

            string storageConnectionString = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["AzureCStoreConnectionStringSecretName"]);
            Kernel.Bind<ITableStorageAccess>()
              .ToMethod(
                  m =>
                  {
                      return new TableStorageAccessor("EventUtilization", storageConnectionString);
                  }
              ).InSingletonScope().Named("EventUtilization");

            Kernel.Bind<IConfigAdapter>().ToConstructor(c =>
                new ConfigAdapter(Kernel.Get<IWebServiceProxy>(), new Uri(ConfigurationManager.AppSettings["ImagesConfigServiceUrl"])));

            Kernel.Bind<ICoreConfigAdapter>().ToConstructor(c =>
                new CoreConfigAdapter(Kernel.Get<ILoggerFactory>(), Kernel.Get<IWebServiceProxy>(), new Uri(ConfigurationManager.AppSettings["ImagesNewConfigServiceBaseAddress"]), "1"));
        }
    }
}
