using System;
using System.Collections.Concurrent;
using System.Configuration;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using syngo.Cloud.PIC.Data.Access.Common.Data;
using syngo.Cloud.PIC.Data.CQRS;
using syngo.Cloud.PIC.Data.CQRS.Query;
using syngo.Cloud.PIC.Data.CQRS.QueryResult;
using syngo.Cloud.PIC.Service.Client.ConfigAdapter;
using syngo.Cloud.PIC.Service.Client.MetadataAdapter;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public class DeleteStudy : IDeleteStudy
    {
        private readonly ILogger myLogger;
        private readonly IConfigAdapter myConfigAdpater;
        private readonly IMetadataAdapter myMetadataAdapter;
        private readonly IQueryDispatcher myQueryDispatcher;

        private readonly int myNumberOfStudiesToBeDeletedInParallel;

        public DeleteStudy(ILoggerFactory loggerFactory, IConfigAdapter configAdpater, IMetadataAdapter metadataAdapter, IQueryDispatcher queryDispatcher)
        {
            myLogger = loggerFactory.CreateLogger<DeleteStudy>();
            myConfigAdpater = configAdpater;
            myMetadataAdapter = metadataAdapter;
            myQueryDispatcher = queryDispatcher;

            myNumberOfStudiesToBeDeletedInParallel = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
        }

        public void Delete(long tenantId, AutoDeletionRules deletionRule)
        {
            try
            {
                GetStudyAndDelete(tenantId, deletionRule);
            }
            catch (Exception ex)
            {
                myLogger.LogError($"Error in executing deletion query for tenantid - {tenantId}, contextId - {deletionRule.ContextId} ex - {ex}");
            }
        }

        private void GetStudyAndDelete(long tenantId, AutoDeletionRules deleteRule)
        {
            if (string.IsNullOrEmpty(deleteRule.AETName) || deleteRule.StudiesNotUpdatedWithinInDays == 0)
            {
                myLogger.LogError($"Wrongly configured rules for tenant - {tenantId}");
                return;
            }
            var studiesToBeDeleted = myQueryDispatcher.Dispatch<StudiesByAetNameAndModifiedDateQuery, StudiesByAetNameAndModifiedDateQueryResult>(new StudiesByAetNameAndModifiedDateQuery()
            {
                TenantId = tenantId,
                AetName = deleteRule.AETName,
                ContextId = deleteRule.ContextId,
                StudiesNotUpdatedWithinInDays = deleteRule.StudiesNotUpdatedWithinInDays,
                IsPartnerAppsResultsToBeConsidered = deleteRule.PartnerAppsResultsToBeConsidered,
                DisabledForTenants = deleteRule.DisabledForTenants == null ? new long[] { } : deleteRule.DisabledForTenants.ToArray()
            });

            myLogger.LogInformation($"Total number studies to be considered for deletion - {studiesToBeDeleted.Count} - (This number could be filtered later after rules execution)");

            var deletedStudiesBag = new ConcurrentBag<string>();

            Parallel.ForEach(studiesToBeDeleted, new ParallelOptions() { MaxDegreeOfParallelism = myNumberOfStudiesToBeDeletedInParallel }, (studyToDelete) =>
            {
                try
                {
                    myMetadataAdapter.DeleteStudy(studyToDelete.TenantId, studyToDelete.ContextId, studyToDelete.StudyInstanceUid);
                    deletedStudiesBag.Add(studyToDelete.StudyInstanceUid);
                    myLogger.LogWarning($"Study - {studyToDelete.StudyInstanceUid} belonging to tenant - {studyToDelete.TenantId}, context - {studyToDelete.ContextId} is requested for deletion.");
                }
                catch (Exception ex)
                {
                    myLogger.LogError($"Error in performing study deletion for , tenantid - {studyToDelete.TenantId}, context - {studyToDelete.ContextId}, studyinstanceuid - {studyToDelete.StudyInstanceUid} , exception is - {ex}");
                }
            });

            myLogger.LogInformation($"Total number of studies requested for deletion : {deletedStudiesBag.Count}");
        }
    }
}
