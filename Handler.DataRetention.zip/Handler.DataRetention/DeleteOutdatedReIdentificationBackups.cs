using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Castle.Core.Internal;
using Images.Sdk.Storage.Blob;
using Microsoft.Extensions.Logging;
using Ninject;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public class DeleteOutdatedReIdentificationBackups : IDeleteOutdatedReIdentificationBackups
    {
        private readonly IBlobAccess myBlobAccess;

        private readonly ILogger myLogger;

        private readonly int myMaxDegreeOfParallelism;


        public DeleteOutdatedReIdentificationBackups([Named("BlobAccessorForReIdentificationBackup")] IBlobAccess blobAccess, ILoggerFactory loggerFactory)
        {
            myBlobAccess = blobAccess;

            myLogger = loggerFactory.CreateLogger<DeleteOutdatedReIdentificationBackups>();

            myMaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
        }

        public void Process()
        {
            try
            {
                // Determine date limit. Files older than the limit shall be deleted.
                string deleteBackupsOlderThanDaysConfig = ConfigurationManager.AppSettings["DeleteReIdentificationBackupsOlderThanDays"];

                if (!int.TryParse(deleteBackupsOlderThanDaysConfig, out int deleteBackupsOlderThanDays))
                {
                    myLogger.LogWarning($"DeleteBackupsOlderThanDays could not be parsed from Configuration");
                    deleteBackupsOlderThanDays = 30;
                }
                DateTime dateLimit = DateTime.UtcNow.AddDays(-deleteBackupsOlderThanDays);

                myLogger.LogInformation($"ReIdentificationBackups older than {deleteBackupsOlderThanDays} days (older than {dateLimit}) are considered for deletion");

                // Get the list of backup files
                var blobInfos = myBlobAccess.Enumerate(ConfigurationManager.AppSettings["BackupsContainerName"]);

                if (!blobInfos.IsNullOrEmpty())
                {
                    // Get the list of all backup files which are older than the limit
                    var dbBackupBlobInfosToDelete = blobInfos.Where(blobInfo => ShallBlobBeDeleted(blobInfo, dateLimit)).ToList();

                    myLogger.LogInformation($"Total number of backups with related metadata to be considered for deletion: {dbBackupBlobInfosToDelete.Count / 2}");

                    // Delete all blobs which are older than the limit
                    Parallel.ForEach(dbBackupBlobInfosToDelete, new ParallelOptions() { MaxDegreeOfParallelism = myMaxDegreeOfParallelism }, (dbBackupBlobInfoToDelete) =>
                    {
                        var completeBlobname = GetCompleteBlobNameFromInfo(dbBackupBlobInfoToDelete);

                        Task.Run(async () => await myBlobAccess.DeleteAsync(completeBlobname)).Wait();

                        myLogger.LogInformation($"Deleted backup file {completeBlobname}.");
                    });
                }
            }
            catch (Exception ex)
            {
                myLogger.LogError($"Error in performing backup deletion, exception is {ex}");
            }
        }

        private bool ShallBlobBeDeleted(string blobInfo, DateTime dateLimit)
        {
            myLogger.LogInformation($"BlobInfo: {blobInfo}");
            DateTime blobInfoDateTime = GetDateTimeFromBlobInfo(blobInfo);
            return (!blobInfoDateTime.Equals(DateTime.MinValue) && blobInfoDateTime.Date <= dateLimit.Date);
        }

        private DateTime GetDateTimeFromBlobInfo(string blobInfo)
        {
            DateTime fileDateTime = DateTime.MinValue;

            var infoParts = blobInfo.Split(',');

            if (infoParts.Length == 7)
            {
                string blobName = infoParts[1];

                var blobNameParts = blobName.Split(Path.AltDirectorySeparatorChar);

                if (blobNameParts.Length >= 3)
                {
                    try
                    {
                        fileDateTime = DateTime.ParseExact(blobNameParts[2].Substring(0, 22), "yyyy_MM_dd_hh_mm_ss_tt", CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        myLogger.LogError($"Failed to determine DateTime from Blob name {blobName}");
                    }
                }
            }
            return fileDateTime;
        }

        private static string GetCompleteBlobNameFromInfo(string blobInfo)
        {
            var infoParts = blobInfo.Split(',');

            string completeBlobName = infoParts[0] + "/" + infoParts[1];

            return completeBlobName;
        }
    }
}
