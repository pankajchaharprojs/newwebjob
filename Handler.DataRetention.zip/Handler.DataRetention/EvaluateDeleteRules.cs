using Microsoft.Extensions.Logging;
using syngo.Cloud.PIC.Data.Access.Common.Data;
using syngo.Cloud.PIC.Data.CQRS;
using syngo.Cloud.PIC.Data.CQRS.Query;
using syngo.Cloud.PIC.Data.CQRS.QueryResult;
using syngo.Cloud.PIC.Service.Client.ConfigAdapter;
using syngo.Cloud.PIC.Service.Client.CoreConfigAdapter;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public class EvaluateDeleteRules : IEvaluateDeleteRules
    {
        private readonly ICoreConfigAdapter myCoreConfigAdpater;
        private readonly IDeleteStudy myDeleteStudy;
        private readonly IQueryDispatcher myQueryDispatcher;

        private readonly int myMaxNumberOfParallelism;
        private readonly int myMaxNumberOfDeleteQueriesToBeRunInParallel;
        private readonly ILogger myLogger;

        public EvaluateDeleteRules(ICoreConfigAdapter coreConfigAdpater, IDeleteStudy deleteStudy, IQueryDispatcher queryDispatcher, ILoggerFactory loggerFactory)
        {
            myCoreConfigAdpater = coreConfigAdpater;
            myDeleteStudy = deleteStudy;
            myQueryDispatcher = queryDispatcher;

            myMaxNumberOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
            if (!int.TryParse(ConfigurationManager.AppSettings["MaxNumberOfDeleteQueriesToBeRunInParallel"], out myMaxNumberOfDeleteQueriesToBeRunInParallel))
            {
                myMaxNumberOfDeleteQueriesToBeRunInParallel = 3;
            }
            myLogger = loggerFactory.CreateLogger<EvaluateDeleteRules>();
        }

        public void Process()
        {
            var uniqueTenantIds = GetUniqueTenantIdsFromDatabase();
            var deleteRuleList = GetAutoDeletionRules(uniqueTenantIds);
            myLogger.LogInformation($"Total auto deletion rules - {deleteRuleList.Count}");
            var tenantSpecificRules = deleteRuleList.Where(rules => rules.TenantId != "All" && !string.IsNullOrEmpty(rules.TenantId)).ToList();
            ExecuteRules(tenantSpecificRules);

            //Global rules

            var glabalRule = deleteRuleList.FirstOrDefault(rules => rules.TenantId == "All");
            if (glabalRule != null)
            {
                ExecuteGlobalRuleForTenants(glabalRule, uniqueTenantIds);
            }
        }

        private void ExecuteRules(List<TenantWiseAutoDeletionRules> deleteRules)
        {
            Parallel.ForEach(deleteRules, new ParallelOptions() { MaxDegreeOfParallelism = myMaxNumberOfDeleteQueriesToBeRunInParallel }, (deleteRule) =>
            {
                long tenantId;
                if (!long.TryParse(deleteRule.TenantId, out tenantId))
                {
                    return;
                }
                var rules = deleteRule.Rules;
                foreach (var rule in rules)
                {
                    myDeleteStudy.Delete(tenantId, rule);
                }
            });
        }

        private void ExecuteGlobalRuleForTenants(TenantWiseAutoDeletionRules tenantWiseAutoDeletionRules, List<long> uniqueTenantIds)
        {
            foreach (var rule in tenantWiseAutoDeletionRules.Rules)
            {
                var tenantIdsFiltered = uniqueTenantIds.Where(x => !rule.DisabledForTenants.Any(y => y == x)).ToList();
                Parallel.ForEach(tenantIdsFiltered, new ParallelOptions() { MaxDegreeOfParallelism = myMaxNumberOfDeleteQueriesToBeRunInParallel }, (tenantId) =>
                {
                    myDeleteStudy.Delete(tenantId, rule);
                });
            }
        }

        private List<TenantWiseAutoDeletionRules> GetAutoDeletionRules(List<long> uniqueTenantIds)
        {
            var globalAutoDeletionRules = new List<TenantWiseAutoDeletionRules>();
            if (uniqueTenantIds == null)
            {
                return globalAutoDeletionRules;
            }

            Parallel.ForEach(uniqueTenantIds, new ParallelOptions() { MaxDegreeOfParallelism = myMaxNumberOfParallelism }, (tenantId) =>
            {
                var rules = new List<AutoDeletionRules>();

                CreateDeletionRulesForImagesAeTitles(tenantId, rules);
                CreateDeletionRulesForPartnerApps(tenantId, rules);

                if (rules.Count > 0)
                {
                    globalAutoDeletionRules.Add(new TenantWiseAutoDeletionRules() { TenantId = tenantId.ToString(), Rules = rules });
                }
            });

            return globalAutoDeletionRules;
        }

        private void CreateDeletionRulesForImagesAeTitles(long tenantId, List<AutoDeletionRules> rules)
        {
            var imageOrMobilePartnerAppId = Convert.ToString(ConfigurationManager.AppSettings["ImageOrMobilePartnerAppId"]);
            var partnerAppAets = Task.Run(async () => await myCoreConfigAdpater.GetPartnerAppAeTitles(tenantId.ToString()).ConfigureAwait(false)).Result;
            if (partnerAppAets != null)
            {
                var partnerAppAet = partnerAppAets.Find(x => x.PartnerAppId == imageOrMobilePartnerAppId);
                if (partnerAppAet != null)
                {
                    var imagesAets = partnerAppAet.DicomAETitles;
                    if (imagesAets != null)
                    {
                        rules.AddRange(from aet in imagesAets
                                       where aet.IsDataRetentionActivated
                                       select new AutoDeletionRules()
                                       {
                                           AETName = aet.Title,
                                           ContextId = partnerAppAet.ContextId,
                                           Enabled = aet.IsDataRetentionActivated,
                                           StudiesNotUpdatedWithinInDays = aet.DataRetentionInDays,
                                           NotSharedWithInstitution = aet.KeepPersonallySharedStudies
                                       });
                    }
                }
            }
        }

        private void CreateDeletionRulesForPartnerApps(long tenantId, List<AutoDeletionRules> rules)
        {
            var partnerApps = Task.Run(async () => await myCoreConfigAdpater.GetPartnerAppAeTitles(tenantId.ToString()).ConfigureAwait(false)).Result;
            if (partnerApps != null)
            {
                foreach (var partnerApp in partnerApps)
                {
                    if (partnerApp.DicomAETitles != null)
                    {
                        rules.AddRange(from aet in partnerApp.DicomAETitles
                                       where aet.IsDataRetentionActivated
                                       select new AutoDeletionRules()
                                       {
                                           AETName = aet.Title,
                                           ContextId = partnerApp.ContextId,
                                           Enabled = aet.IsDataRetentionActivated,
                                           StudiesNotUpdatedWithinInDays = aet.DataRetentionInDays,
                                           NotSharedWithInstitution = aet.KeepPersonallySharedStudies
                                       });
                    }
                }
            }
        }

        private List<long> GetUniqueTenantIdsFromDatabase()
        {
            return myQueryDispatcher.Dispatch<UniqueTenantIdsFromAllStudiesQuery, UniqueTenantIdsFromAllStudiesQueryResult>(new UniqueTenantIdsFromAllStudiesQuery());
        }
    }
}
