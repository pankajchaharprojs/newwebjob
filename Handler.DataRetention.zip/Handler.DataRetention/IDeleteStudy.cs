using syngo.Cloud.PIC.Data.Access.Common.Data;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public interface IDeleteStudy
    {
        void Delete(long tenantId, AutoDeletionRules deletionRule);
    }
}
