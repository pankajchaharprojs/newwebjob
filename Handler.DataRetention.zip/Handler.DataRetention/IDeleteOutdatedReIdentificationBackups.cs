﻿namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public interface IDeleteOutdatedReIdentificationBackups
    {
        void Process();
    }
}
