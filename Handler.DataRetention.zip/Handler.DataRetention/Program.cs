﻿using System;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            var dataRetentionWebjob = new DataRetentionWebJob();
            dataRetentionWebjob.Initialize(args);
            dataRetentionWebjob.EvaluateAutoDeleteRules();
            dataRetentionWebjob.DeleteOutdatedReIdentificationBackups();
        }
    }
}
