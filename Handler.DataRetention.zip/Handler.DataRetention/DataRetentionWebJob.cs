using Ninject;
using Ninject.Modules;
using syngo.Cloud.PIC.Data.CQRS;
using syngo.Cloud.PIC.Handler.Common;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public class DataRetentionWebJob : BaseWebJob
    {
        private const string WebJobName = "DataRetention";

        protected override IList<INinjectModule> GetNinjectModules()
        {
            return new List<INinjectModule>()
            {
                new NinjectModule(),
                new ExternalDependentNinjectModule(),
                new QueryNinjectModule()
            };
        }

        public void EvaluateAutoDeleteRules()
        {
            try
            {
                Kernel.Get<IEvaluateDeleteRules>().Process();
            }
            catch(Exception exception)
            {
                ErrorDetails handlerErrorDetails = new ErrorDetails
                {
                    Message = $"::Images WebJob Failure::",
                    ExceptionSource = WebJobName,
                    TenantId = "ALL",
                    ContextId = "ALL",
                    AdditionalDetails = new Newtonsoft.Json.Linq.JObject { { "ActionName", "DataRetention" } },
                    Exception = exception
                };
                Kernel.Get<IExceptionLogger>().LogException(handlerErrorDetails);
                throw;
            }
        }

        public void DeleteOutdatedReIdentificationBackups()
        {
            try
            {
                Kernel.Get<IDeleteOutdatedReIdentificationBackups>().Process();
            }
            catch (Exception exception)
            {
                ErrorDetails handlerErrorDetails = new ErrorDetails
                {
                    Message = $"::Images WebJob Failure::",
                    ExceptionSource = WebJobName,
                    TenantId = "ALL",
                    ContextId = "ALL",
                    AdditionalDetails = new Newtonsoft.Json.Linq.JObject { { "ActionName", "ReIdentification Backup Data Retention" } },
                    Exception = exception
                };
                Kernel.Get<IExceptionLogger>().LogException(handlerErrorDetails);
                throw;
            }
        }

    }
}
