namespace syngo.Cloud.PIC.Handler.DataRetention
{
    public interface IEvaluateDeleteRules
    {
        void Process();
    }
}
