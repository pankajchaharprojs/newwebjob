using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using HTTPDataCollectorAPI;
using Images.Sdk.Redis;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class OperationExecutionTracker : IOperationExecutionTracker
    {
        private readonly ILogger myLogger;
        private ConcurrentDictionary<string, Stopwatch> myOperationTimeStamps = new ConcurrentDictionary<string, Stopwatch>();
        private bool myReExecuteOperationsOnSameMessageOnRetry;
        private readonly ICollector myCollector;
        private IRedisDatabase myRedisDatabase;

        public OperationExecutionTracker(ILoggerFactory loggerFactory, IRedisDatabase redisDatabase, 
            INameResolver nameResolver, ICollector collector)
        {
            myLogger = loggerFactory.CreateLogger<OperationExecutionTracker>();
            myRedisDatabase = redisDatabase;
            myReExecuteOperationsOnSameMessageOnRetry = Boolean.Parse(nameResolver.Resolve("ReExecuteOperationsOnSameMessageOnRetry"));
            myCollector = collector;
        }

        public bool WasThisMessageExecutedSuccessfully(string webJobName, string messageId, string operationName)
        {
            if (!myReExecuteOperationsOnSameMessageOnRetry && IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId))
            {
                return myRedisDatabase.SetMembers($"{webJobName}-{messageId}").Contains(operationName);
            }
            return false;
        }

        public void ExecutionStarted(string webJobName, string messageId, string operationName)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId))
            {
                var stopWatch = Stopwatch.StartNew();
                myOperationTimeStamps.AddOrUpdate($"{webJobName}-{messageId}-{operationName}", (c) => stopWatch, (m, n) => stopWatch);
            }
        }

        public void ExecutedSuccessfully(string webJobName, string messageId, string operationName, bool executeMeOnRetryOfSameMessage, string message)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId, operationName))
            {
                if (!myReExecuteOperationsOnSameMessageOnRetry)
                {
                    if (!executeMeOnRetryOfSameMessage)
                    {
                        myRedisDatabase.SetAdd($"{webJobName}-{messageId}", operationName);
                        myRedisDatabase.KeyExpire($"{webJobName}-{messageId}", TimeSpan.FromHours(4));
                    }
                    else
                    {
                        myLogger.LogInformation($"As requested, skipping marking of message {webJobName}-{messageId} as executed successfully by operation {operationName}, it would be re-executed next time.");
                    }
                }

                MeasureTimeTaken(webJobName, messageId, message, operationName);
            }
        }

        public void ExecutionFailed(string webJobName, string messageId, string operationName, string message)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId, operationName))
            {
                MeasureTimeTaken(webJobName, messageId, message, operationName);
            }
        }

        public void ExecutionStarted(string webJobName, string messageId)
        {
            if (IsMessageIdNotNullOrEmpty(messageId))
            {
                var stopWatch = Stopwatch.StartNew();
                myOperationTimeStamps.AddOrUpdate($"{webJobName}-{messageId}", (c) => stopWatch, (m, n) => stopWatch);
            }
        }

        public void ExecutedSuccessfully(string webJobName, string messageId, string message)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId))
            {
                myRedisDatabase.KeyDelete($"{webJobName}-{messageId}");
                MeasureTimeTaken(webJobName, messageId, message);
            }
        }

        public void ExecutionFailed(string webJobName, string messageId, string message)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId))
            {
                MeasureTimeTaken(webJobName, messageId, message);
            }
        }

        public void StopTracking(string webJobName, string messageId)
        {
            if (IsMessageIdNotNullOrEmpty(messageId) && HasStarted(webJobName, messageId))
            {
                myRedisDatabase.KeyDelete($"{webJobName}-{messageId}");
            }
        }

        private void MeasureTimeTaken(string webJobName, string messageId, string message, string operationName = null)
        {
            var key = string.IsNullOrEmpty(operationName) ? $"{webJobName}-{messageId}" : $"{webJobName}-{messageId}-{operationName}";

            Stopwatch stopWatch;
            myOperationTimeStamps.TryRemove(key, out stopWatch);
            stopWatch.Stop();

            var operationMessage = string.IsNullOrEmpty(operationName) ? "all operations" : $"operation {operationName}";
            myLogger.LogInformation($"Time taken to execute {operationMessage} on message {webJobName}-{messageId} is {stopWatch.ElapsedMilliseconds} ms");

            LogPerformanceCounter(webJobName, operationName, message, stopWatch.ElapsedMilliseconds);
        }

        private bool HasStarted(string webJobName, string messageId, string operationName = null)
        {
            var key = string.IsNullOrEmpty(operationName) ? $"{webJobName}-{messageId}" : $"{webJobName}-{messageId}-{operationName}";
            return myOperationTimeStamps.ContainsKey(key);
        }

        private static bool IsMessageIdNotNullOrEmpty(string messageId)
        {
            return !string.IsNullOrEmpty(messageId);
        }

        private void LogPerformanceCounter(string webJobName, string operationName, string message, long elapsedMilliseconds)
        {
            try
            {
                var performanceData = new
                {
                    Message_WebjobName = webJobName,
                    Message_OperationName = operationName ?? webJobName,
                    Message_ElapsedMilliseconds = elapsedMilliseconds,
                    Message_DicomDataStorage = "Cloud",
                    Message_AdditionalProperties = message,
                    Message_CreatedDateTime = DateTime.UtcNow
                };
                myCollector.Collect("ReportImagesWebJobUtilization", performanceData);
            }
            catch (Exception ex)
            {
                myLogger.LogError($"Error when collecting performance counter for Webjob: {webJobName}, operation: {operationName} with exception: {ex}");
            }
        }
    }
}
