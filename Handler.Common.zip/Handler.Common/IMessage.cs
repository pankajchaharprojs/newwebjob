﻿namespace syngo.Cloud.PIC.Handler.Common
{
    public interface IMessage
    {
        string MessageId { get; }
    }
}
