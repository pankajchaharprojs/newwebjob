using System.Collections.Generic;

namespace syngo.Cloud.PIC.Handler.Common
{
    public interface IOperationExecutionTracker
    {
        bool WasThisMessageExecutedSuccessfully(string webJobName, string messageId, string operationName);

        void ExecutionStarted(string webJobName, string messageId, string operationName);

        void ExecutedSuccessfully(string webJobName, string messageId, string operationName, bool executeMeOnRetryOfSameMessage, string message);

        void ExecutionFailed(string webJobName, string messageId, string operationName, string message);

        void ExecutionStarted(string webJobName, string messageId);

        void ExecutedSuccessfully(string webJobName, string messageId, string message);

        void ExecutionFailed(string webJobName, string messageId, string message);

        void StopTracking(string webJobName, string messageId);
    }
}
