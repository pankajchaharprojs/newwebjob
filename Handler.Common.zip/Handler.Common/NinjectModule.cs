using System;
using System.Configuration;
using System.Globalization;
using Gravity.SDK.KeyVault.Helpers;
using HTTPDataCollectorAPI;
using Images.Sdk.Dicom.Helpers;
using Images.Sdk.Redis;
using Images.Sdk.Service.Client.TokenAdapter;
using Images.Sdk.Storage.Blob;
using LogAnalytics.Extensions.Logging;
using Microsoft.Extensions.Logging;
using Ninject;
using StackExchange.Redis;
using syngo.Cloud.PIC.Data.Access.Common.ConfigureWorkerThread;
using syngo.Cloud.PIC.Data.Access.Common.Hashing;
using syngo.Cloud.PIC.Data.Access.Storage.Blob;
using syngo.Cloud.PIC.Data.Access.Storage.Blob.Interfaces;
using syngo.Cloud.PIC.Data.Access.Storage.Blob.PathFormatters;
using syngo.Cloud.PIC.Service.Client.NetworkAdapter;
using TokenAdapter = syngo.Cloud.PIC.Service.Client.TokenAdapter;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class NinjectModule : Ninject.Modules.NinjectModule
    {
        public override void Load()
        {
            var nameResolver = new KeyValueResolver();
            Kernel.Bind<INameResolver>().ToMethod(m => nameResolver).InSingletonScope();
            var keyVaultHelper = new KeyVaultHelper();
            Kernel.Bind<IKeyVaultHelper>().ToMethod(m => keyVaultHelper).InSingletonScope();

            Kernel.Bind<IHttpWebClient>().To<HttpWebClient>();
            Kernel.Bind<ITokenAdapter>().ToConstructor(c =>
                new TokenAdapter.Auth0TokenAdapter(Kernel.Get<ILoggerFactory>(),
                        Kernel.Get<IHttpWebClient>(),
                        new TokenAdapter.ApiManagementDetails
                        {
                            ApiManagementUrl = new Uri(ConfigurationManager.AppSettings["ApiManagementUrl"]),
                            CoreApiSubscriptionKey = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["CoreApiPrimaryKeySecretName"]),
                            MaxHttpRetry = int.Parse(ConfigurationManager.AppSettings["HttpMaxRetries"], CultureInfo.InvariantCulture)
                        },
                        new TokenAdapter.Auth0Details
                        {
                            ClientId = ConfigurationManager.AppSettings["Auth0ClientId"],
                            ClientSecret = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["Auth0ClientSecretName"]),
                            Audience = ConfigurationManager.AppSettings["Audience"]
                        })).InSingletonScope();

            string storageConnectionString = keyVaultHelper.GetSecret(nameResolver.Resolve(Keys.AzureCStoreConnectionStringSecretName));

            CreateBlobAccessor(nameResolver, storageConnectionString);
            
            Kernel.Bind<IRedisDatabase>().ToConstructor(c => new RedisDatabase(Kernel.Get<ILoggerFactory>(),
                keyVaultHelper.GetSecret(nameResolver.Resolve(Keys.RedisCacheConfigString)))).InSingletonScope();
            Kernel.Bind<IConnectionMultiplexer>().ToMethod(c => { Kernel.Get<IRedisDatabase>(); return Redis.Connection; }).InSingletonScope();

            Kernel.Bind<IConfigureWorkerThread>().To<ConfigureWorkerThread>().InSingletonScope();
            Kernel.Bind<ICollector>().ToMethod(m =>
            {
                var logAnalyticsWorkspaceIdSecret = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["LogAnalyticsWorkspaceIdSecretName"]);
                var logAnalyticsSharedKeySecret = keyVaultHelper.GetSecret(ConfigurationManager.AppSettings["LogAnalyticsSharedKeySecretName"]);
                return new Collector(logAnalyticsWorkspaceIdSecret, logAnalyticsSharedKeySecret, ConfigurationManager.AppSettings["CloudServiceEndPoint"]);
            }).InSingletonScope();
            ConfigureLogging();
        }

        private void CreateBlobAccessor(KeyValueResolver nameResolver, string storageConnectionString)
        {
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            CreateBlobAccessor(nameResolver, storageConnectionString, config, "true", "BlobAccessorForDecryption");
            CreateBlobAccessor(nameResolver, storageConnectionString, config, "false", "BlobAccessorForEncryption");

            Kernel.Bind<IBlobAccessEncryption>().To<BlobAccessEncryption>().InSingletonScope();
            Kernel.Bind<IBlobAccessDecryption>().To<BlobAccessDecryption>().InSingletonScope();

            Kernel.Bind<IStorageAccessorFacade>().To<StorageAccessorFacade>().InTransientScope();
            Kernel.Bind<IStoragePathGenerator>().To<StoragePathGenerator>().InTransientScope();
            Kernel.Bind<IStorageAccessor>().To<StorageAccessor>().InTransientScope();
            Kernel.Bind<IPrivacyLevelAndDataSourceIdFetcher>().To<PrivacyLevelAndDataSourceIdFetcher>().InTransientScope();
            Kernel.Bind<ICryptoHashTransformer>().To<CryptoHashTransformer>().InTransientScope();
            Kernel.Bind<ICryptoHasher>().To<CryptoHasher>().InTransientScope();
            Kernel.Bind<IDicomCompliantUidHasher>().To<DicomCompliantUidHasher>().InTransientScope();
            Kernel.Bind<IBlobPathFormatterFactory>().To<BlobPathFormatterFactory>().InTransientScope();
            Kernel.Bind<IExceptionLogger>().To<ExceptionLogger>().InSingletonScope();

        }

        private void CreateBlobAccessor(KeyValueResolver nameResolver, string storageConnectionString, Configuration config, string useKeyVault, string bindName)
        {
            config.AppSettings.Settings.Remove("useKeyVault");
            config.AppSettings.Settings.Add("useKeyVault", useKeyVault);
            config.Save(ConfigurationSaveMode.Modified, true);
            ConfigurationManager.RefreshSection("appSettings");


            var blobAccess = new BlobAccessor(storageConnectionString);
            Kernel.Bind<IBlobAccess>().ToMethod(m => blobAccess).InSingletonScope().Named(bindName);
        }

        private void ConfigureLogging()
        {
            string workspaceId = Kernel.Get<IKeyVaultHelper>().GetSecret(ConfigurationManager.AppSettings["LogAnalyticsWorkspaceIdSecretName"]);
            string sharedKeySecret = Kernel.Get<IKeyVaultHelper>().GetSecret(ConfigurationManager.AppSettings["LogAnalyticsSharedKeySecretName"]);
            string logAnalyticsTableName = ConfigurationManager.AppSettings["LogAnalyticsTableName"];
            string cloudServiceEndpoint = ConfigurationManager.AppSettings["CloudServiceEndPoint"];
            LogLevel logLevel;
            Enum.TryParse<LogLevel>(ConfigurationManager.AppSettings["LogAnalyticsLogLevel"], out logLevel);

            var loggerFactory = new LoggerFactory();
            loggerFactory.AddLogAnalytics(workspaceId,
                sharedKeySecret,
                logAnalyticsTableName,
                logLevel, cloudServiceEndpoint
                );

            Kernel.Bind<ILoggerFactory>().ToConstant(loggerFactory).InSingletonScope();
        }
    }
}
