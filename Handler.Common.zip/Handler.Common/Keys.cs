namespace syngo.Cloud.PIC.Handler.Common
{
    public static class Keys
    {
        public const string SyngoCloudBlobAdapterName = "syngoCloudBlobAdapterName";
        public const string DashboardConnectionString = "AzureLogStoreConnectionStringSecretName";
        public const string StorageConnectionString = "AzureLogStoreConnectionStringSecretName";
        public const string AzureCStoreConnectionStringSecretName = "AzureCStoreConnectionStringSecretName";
        public const string ServiceBusConnectionString = "PublisherServiceBusConnectionStringSecretName";
        public const string MaxConcurrentCalls = "MaxConcurrentCalls";
        public const string ServiceBusTopicName = "ServiceBusTopicName";
        public const string ServiceBusTopicSubscriptionName = "ServiceBusTopicSubscriptionName";
        public const string RedisCacheConfigString = "RedisConnectionStringSecretName";
    }
}
