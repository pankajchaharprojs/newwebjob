using Ninject;
using Microsoft.Extensions.Logging;
using syngo.Cloud.PIC.Handler.Common.Operation;
using System;
using System.Diagnostics;
using System.Reflection;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class BaseOperationWebJob : BaseWebJob
    {
        private static readonly Type MyDeclaringType = MethodBase.GetCurrentMethod().DeclaringType;
        private static readonly ILogger MyLogger = new LoggerFactory().CreateLogger(MyDeclaringType);

        protected override void InitializeComponents()
        {
            base.InitializeComponents();

            Kernel.Bind<IOperationBuilder>().To<OperationBuilder>();
            Kernel.Bind<IOperationExecutionTracker>().To<OperationExecutionTracker>().InSingletonScope();

            Kernel.Bind<IOperationConfiguration>().To<OperationConfiguration>().InSingletonScope();
            Kernel.Get<IOperationConfiguration>().Initialize();
        }

        protected void ExecuteOperations<T>(string webJobName, T message) where T : IMessage
        {
            var watch = Stopwatch.StartNew();

            var operationBuilder = Kernel.Get<IOperationBuilder>();
            var operation = operationBuilder.Build<T>(webJobName, Kernel.Get<IOperationConfiguration>().GetOperationNames(webJobName));

            watch.Stop();
            MyLogger.LogInformation($"Time taken to build operations is {watch.ElapsedMilliseconds} ms");

            operation.StartExecution(message);
        }
    }
}
