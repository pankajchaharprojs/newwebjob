﻿using System.Collections.Concurrent;
using System.Configuration;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class KeyValueResolver : INameResolver
    {
        private readonly ConcurrentDictionary<string, string> cache = new ConcurrentDictionary<string, string>();

        public string Resolve(string name)
        {
            return this.cache.GetOrAdd(name, (key) => ConfigurationManager.AppSettings[key]);
        }
    }
}
