// (c) Siemens Healthcare GmbH / Siemens Medical Solutions USA Inc. 2019. All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using syngo.Cloud.PIC.Service.Client.MetadataAdapter;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class ContextResolver : IResolver
    {
        private readonly IMetadataAdapter myMetadataAdapter;
        public ContextResolver(IMetadataAdapter metadataAdapter)
        {
            myMetadataAdapter = metadataAdapter;
        }

        public long ResolveContext<T>(T message)
        {
            var tenantId = (long)GetPropValue(message, "TenantId");
            var contextId = (long)GetPropValue(message, "ContextId");
            var studyInstanceUid = (string)GetPropValue(message, "StudyInstanceUid");

            //Ti48: During prod deployment, if messages are stuck in queue will not have contextId, resolving them here
            if (contextId == 0)
            {
                List<long> contextIds = Task.Run(async () => await myMetadataAdapter.GetContextIdsAsync(tenantId, studyInstanceUid)).ConfigureAwait(false).GetAwaiter().GetResult();
                if (contextIds == null || contextIds.Count == 0 || contextIds.Count > 1)
                {
                    throw new NotSupportedException($"Unable to resolve contextId for Sc45 messages with tenant: {tenantId} study: {studyInstanceUid}");
                }
                return contextIds.FirstOrDefault();
            }
            return contextId;
        }

        public static object GetPropValue(object source, string propertyName)
        {
            var property = source.GetType().GetRuntimeProperties().FirstOrDefault(p => string.Equals(p.Name, propertyName, StringComparison.OrdinalIgnoreCase));
            return property?.GetValue(source);
        }
    }

    public interface IResolver
    {
        long ResolveContext<T>(T message);
    }
}
