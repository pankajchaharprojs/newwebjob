using Newtonsoft.Json.Linq;
using System;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class ErrorDetails
    {
        public string ExceptionSource { get; set; }
        public string TenantId { get; set; }
        public string ContextId { get; set; }
        public string Message { get; set; }
        public Exception Exception { get; set; }
        public JObject AdditionalDetails { get; set; }
    }
}
