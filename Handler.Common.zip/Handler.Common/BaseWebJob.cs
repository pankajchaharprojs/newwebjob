using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Gravity.SDK.KeyVault.Helpers;
using Images.Sdk.Storage.Blob;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Ninject;
using Ninject.Modules;
using syngo.Cloud.PIC.Data.Access.Common.ConfigureWorkerThread;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class BaseWebJob : IDisposable
    {
        private bool myStandaloneMode;

        public IKernel Kernel { get; set; }
        public INameResolver NameResolver { get; set; }
        public IKeyVaultHelper KeyVaultHelper { get; set; }
        public IBlobAccess BlobAccess { get; set; }

        public BaseWebJob Initialize(string[] args)
        {
            ConfigureServicePointManager();
            this.myStandaloneMode = args.Contains("-b");
            InitializeDatabase(args.Contains("-r"));
            CreateKernel();
            InitializeComponents();
            return this;
        }

        private static void ConfigureServicePointManager()
        {
            ServicePointManager.DefaultConnectionLimit = 10 * Environment.ProcessorCount;
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.EnableDnsRoundRobin = true;
        }

        protected virtual void InitializeDatabase(bool dropCreateDb)
        {
        }

        private void CreateKernel()
        {
            Kernel = Kernel ?? new StandardKernel();
        }

        protected virtual void InitializeComponents()
        {
            var ninjectModules = new List<INinjectModule>() { new NinjectModule() };
            ninjectModules.AddRange(GetNinjectModules());

            foreach (var ninjectModule in ninjectModules)
            {
                Kernel.Load(ninjectModule);
            }

            NameResolver = Kernel.Get<INameResolver>();
            KeyVaultHelper = Kernel.Get<IKeyVaultHelper>();
            BlobAccess = Kernel.Get<IBlobAccess>("BlobAccessorForEncryption");
            Kernel.Get<IConfigureWorkerThread>().SetMinThreadsCount();
        }

        protected virtual IList<INinjectModule> GetNinjectModules()
        {
            return new List<INinjectModule>();
        }

        public void Host()
        {
            if (this.myStandaloneMode)
            {
                ProcessImagesInBlobStorage();
            }
            else
            {
                HostWebJob();
            }
        }

        public virtual void ProcessImagesInBlobStorage()
        {
        }

        public virtual void ProcessImagesInBlobStorage(ConcurrentBag<double> timeTaken)
        {
        }

        protected virtual void HostWebJob()
        {
            var builder = new HostBuilder();
            builder.ConfigureWebJobs(webjob =>
            {
                webjob.AddAzureStorageCoreServices();

            })
            .ConfigureServices(services =>
               services.AddSingleton(NameResolver)
            );
            builder.ConfigureLogging((context, b) =>
            {
                b.AddConsole();
            });
            var host = builder.Build();
            using (host)
            {
                RunAndBlock(host);
            }
        }

        /// <summary>
        /// protected virtual only for unit testing purpose                                                                             
        /// </summary>
        /// <param name="jobHost"></param>
        protected virtual void RunAndBlock(IHost jobHost)
        {
            jobHost.Run();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
        }
    }
}
