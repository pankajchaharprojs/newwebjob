using System.Threading.Tasks;
using Images.Sdk.Storage.Blob;
using syngo.Cloud.PIC.Data.Access.Storage.Azure;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class NoClientSideEncryptionOptionsBuilder : IClientSideEncryptionOptionsBuilder
    {
        public Task<ClientSideEncryptionOptions> GetDecryptionMainKeyAsync(long tenantId)
        {
            return Task.FromResult<ClientSideEncryptionOptions>(null);
        }

        public Task<ClientSideEncryptionOptions> GetDecryptionOtherKeyAsync(long tenantId)
        {
            return Task.FromResult<ClientSideEncryptionOptions>(null);
        }

        public Task<ClientSideEncryptionOptions> GetEncryptionMainKeyAsync(long tenantId)
        {
            return Task.FromResult<ClientSideEncryptionOptions>(null);
        }

        public Task<ClientSideEncryptionOptions> GetEncryptionOtherKeyAsync(long tenantId)
        {
            return Task.FromResult<ClientSideEncryptionOptions>(null);
        }
    }
}
