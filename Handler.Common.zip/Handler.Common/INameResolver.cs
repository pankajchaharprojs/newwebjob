﻿
namespace syngo.Cloud.PIC.Handler.Common
{
    public interface INameResolver
    {
        string Resolve(string name);
    }
}
