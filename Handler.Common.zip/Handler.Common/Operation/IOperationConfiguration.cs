﻿using System.Collections.Generic;

namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public interface IOperationConfiguration
    {
        void Initialize();

        IList<string> GetOperationNames(string webJobName);
    }
}
