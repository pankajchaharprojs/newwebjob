using Microsoft.Extensions.Logging;
using Ninject;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public class OperationBuilder : IOperationBuilder
    {
        private static readonly Type MyDeclaringType = MethodBase.GetCurrentMethod().DeclaringType;
        private static readonly ILogger MyLogger = new LoggerFactory().CreateLogger(MyDeclaringType);

        private IKernel myKernel;

        public OperationBuilder(IKernel kernel)
        {
            myKernel = kernel;
        }

        public IOperation<T> Build<T>(string webJobName, IList<string> operationNames) where T: IMessage
        {
            if (operationNames.Count <= 0)
            {
                throw new ArgumentException($"{nameof(operationNames)} is empty!");
            }

            var watch = Stopwatch.StartNew();

            var operation = myKernel.Get<IOperation<T>>(operationNames[0]);
            operation.WebJobName = webJobName;

            watch.Stop();
            MyLogger.LogInformation($"Time taken to build {operationNames[0]} operations is {watch.ElapsedMilliseconds} ms");

            for (int i = 1; i < operationNames.Count; i++)
            {
                watch = Stopwatch.StartNew();

                var nextOperation = myKernel.Get<IOperation<T>>(operationNames[i]);
                nextOperation.WebJobName = webJobName;
                operation.Attach(nextOperation);

                watch.Stop();
                MyLogger.LogInformation($"Time taken to build {operationNames[i]} operations is {watch.ElapsedMilliseconds} ms");
            }
            return operation;
        }
    }
}
