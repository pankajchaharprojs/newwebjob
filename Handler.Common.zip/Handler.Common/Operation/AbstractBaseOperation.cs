using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;

namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public abstract class AbstractBaseOperation<T> : IOperation<T> where T : IMessage
    {
        public string WebJobName { get; set;  }

        protected abstract string Name { get; }


        private readonly IOperationExecutionTracker myOperationExecutionTracker;

        private readonly ILogger myLogger;

        /// <see cref="IOperation{T}.ChildOperation"/>
        public IOperation<T> ChildOperation { get; set; }

        protected AbstractBaseOperation(IOperationExecutionTracker operationExecutionTracker, ILoggerFactory loggerFactory)
        {   
            myOperationExecutionTracker = operationExecutionTracker;
            myLogger = loggerFactory.CreateLogger<AbstractBaseOperation<T>>();
        }

        /// <see cref="IOperation{T}.Attach"/>
        public IOperation<T> Attach(IOperation<T> operation)
        {
            GetLastOperationOfChain().ChildOperation = operation;
            return operation;
        }

        /// <see cref="IOperation{T}.StartExecution"/>
        public void StartExecution(T message)
        {
            bool stopFurtherExecution = false;
            bool executeMeOnRetryOfSameMessage = false;
            string serializedMessage = null;
            if (!myOperationExecutionTracker.WasThisMessageExecutedSuccessfully(WebJobName, message.MessageId, Name))
            {
                myOperationExecutionTracker.ExecutionStarted(WebJobName, message.MessageId, Name);
                try
                {
                    serializedMessage = JsonConvert.SerializeObject(message);
                    Execute(message, out stopFurtherExecution, out executeMeOnRetryOfSameMessage);
                    myOperationExecutionTracker.ExecutedSuccessfully(WebJobName, message.MessageId, Name, executeMeOnRetryOfSameMessage, serializedMessage);
                }
                catch (Exception)
                {
                    myOperationExecutionTracker.ExecutionFailed(WebJobName, message.MessageId, Name, serializedMessage);
                    throw;
                }
            }
            else
            {
                myLogger.LogInformation($"Looks like the message {message.MessageId} has already been processed by operation {Name}; hence skipping re-execution");
            }
            if (!stopFurtherExecution && ChildOperation != null)
            {
                ChildOperation.StartExecution(message);
            }
        }
        
        protected abstract void Execute(T message, out bool stopFurtherExecution, out bool executeMeOnRetryOfSameMessage);

        private IOperation<T> GetLastOperationOfChain()
        {
            IOperation<T> current = this;
            while (current.ChildOperation != null)
            {
                current = current.ChildOperation;
            }
            return current;
        }
    }
}
