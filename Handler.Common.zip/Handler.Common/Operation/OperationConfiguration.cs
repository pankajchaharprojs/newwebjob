﻿using System.Collections.Generic;
using System.Linq;

namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public class OperationConfiguration : IOperationConfiguration
    {
        private static IDictionary<string, IList<string>> myOperationNames = new Dictionary<string, IList<string>>();

        private readonly INameResolver myNameResolver;

        public OperationConfiguration(INameResolver nameResolver)
        {
            myNameResolver = nameResolver;
        }

        public void Initialize()
        {
            myOperationNames.Clear();

            var webJobNames = myNameResolver.Resolve("WebJobNames").Split(',').Select(webJobName => webJobName.Trim()).ToList();
            foreach (var webJobName in webJobNames)
            {
                var webJobMode = myNameResolver.Resolve(webJobName + "WebJobMode");
                var operationNames = myNameResolver.Resolve(webJobMode).Split(',').Select(operationName => operationName.Trim()).ToList();
                myOperationNames.Add(webJobName, operationNames);
            }
        }

        public IList<string> GetOperationNames(string webJobName)
        {
            return myOperationNames[webJobName];
        }
    }
}
