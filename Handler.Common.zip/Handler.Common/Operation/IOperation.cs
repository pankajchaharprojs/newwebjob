﻿namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public interface IOperation<T> where T : IMessage
    {
        string WebJobName { get; set; }

        /// <summary>
        /// The next Operation in the chain.
        /// </summary>
        IOperation<T> ChildOperation { get; set; }

        /// <summary>
        /// Attaches the received Operation to the last Operation in the chain and returns the same received Operation so that Attach API can be used fluently.
        /// </summary>
        IOperation<T> Attach(IOperation<T> operation);

        /// <summary>
        /// Business logic to be executed. Make sure to call this API on first Operation; it takes care to call StartExecution method of all subsequent Operations.
        /// </summary>
        void StartExecution(T message);
    }
}
