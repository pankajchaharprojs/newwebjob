﻿using System.Collections.Generic;

namespace syngo.Cloud.PIC.Handler.Common.Operation
{
    public interface IOperationBuilder
    {
        IOperation<T> Build<T>(string webJobName, IList<string> operationNames) where T : IMessage;
    }
}