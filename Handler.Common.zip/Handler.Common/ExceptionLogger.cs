using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace syngo.Cloud.PIC.Handler.Common
{
    public class ExceptionLogger : IExceptionLogger
    {
        private readonly ILogger Logger = null;

        public ExceptionLogger(ILoggerFactory loggerFactory)
        {
            Logger = loggerFactory.CreateLogger<ExceptionLogger>();
        }

        public void LogException(ErrorDetails exceptionDetails)
        {
            Logger.LogError(JsonConvert.SerializeObject(exceptionDetails));
        }
    }

}
