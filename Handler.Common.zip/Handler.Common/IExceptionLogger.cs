﻿namespace syngo.Cloud.PIC.Handler.Common
{
    public interface IExceptionLogger
    {
        void LogException(ErrorDetails exceptionDetails);
    }
}